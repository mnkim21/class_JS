//javascript > js > ex01.js
alert('하하!!!');
