//ex04.js
// - JavaScript Core 실행 가능
// - JavaScript Browser 실행 불가능

var num = 100;

console.log('num', num);

//Ctrl + F5
//확장 > "Code Runner" > 설치
//Ctrl + Alt + N

if (num > 0) {
	console.log('양수');
} else {
	console.log('음수');
}

for (var i = 0; i < 10; i++) {
	console.log(i);
}
