// ex36.js

//ECMAScript
// - 변수 선언문 반드시 작성해야 한다.

var num = 10;
console.log(num);
