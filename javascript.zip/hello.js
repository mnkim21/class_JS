//javascript > hello.js

/* 

   *.js
   - 자바스크립트 파일

   1. HTML에서 사용되는 전통 자바스크립 파일
      - JavaScript Core + Browser API

   2. Node.js에서 사용되는 자바스크립트 파일
      - JavaScript Core + Node API

*/

//콘솔창에 출력
console.log('hello');

alert('안녕');

a = 10;
